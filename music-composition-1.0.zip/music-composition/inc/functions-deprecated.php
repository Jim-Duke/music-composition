<?php
/**
 * Deprecated functions.
 *
 * @package    MusicComposition
 * @subpackage Includes
 * @author     Jim Duke <jim@dukeboys.org>
 * @copyright  Copyright (c) 2019, Jim Duke
 * @link       https://jim.dukeboys.org/plugins/music-composition
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

/* === Functions removed in 1.0.0 === */

/* TBD - remove everything in this file? */

function mc_sanitize_meta() {}
function mc_breadcrumb_trail_items() {}
function mc_add_meta_boxes() {}
function mc_portfolio_item_info_meta_box_display() {}
function mc_portfolio_item_info_meta_box_save() {}
function mc_admin_head_style() {}
function mc_plugin_settings() {}
function mc_validate_settings() {}
function mc_permalink_section() {}
function mc_root_field() {}
function mc_base_field() {}
function mc_item_base_field() {}
function mc_admin_setup() {}
function mc_edit_portfolio_item_columns() {}
function mc_manage_portfolio_item_columns() {}
