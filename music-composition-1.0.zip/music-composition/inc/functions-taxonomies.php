<?php
/**
 * File for registering custom taxonomies.
 *
 * @package    MusicComposition
 * @subpackage Includes
 * @author     Jim Duke <jim@dukeboys.org>
 * @copyright  Copyright (c) 2019, Jim Duke
 * @link       https://jim.dukeboys.org/plugins/music-composition
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

# Register taxonomies on the 'init' hook.
add_action( 'init', 'mc_register_taxonomies', 9 );

# Filter the term updated messages.
add_filter( 'term_updated_messages', 'mc_term_updated_messages', 5 );

/**
 * Returns the name of the portfolio category taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return string
 */
function mc_get_category_taxonomy() {

	return apply_filters( 'mc_get_category_taxonomy', 'portfolio_category' );
}

/**
 * Returns the name of the portfolio tag taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return string
 */
function mc_get_tag_taxonomy() {

	return apply_filters( 'mc_get_tag_taxonomy', 'portfolio_tag' );
}

/**
 * Returns the capabilities for the portfolio category taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return array
 */
function mc_get_category_capabilities() {

	$caps = array(
		'manage_terms' => 'manage_portfolio_categories',
		'edit_terms'   => 'edit_portfolio_categories',
		'delete_terms' => 'delete_portfolio_categories',
		'assign_terms' => 'assign_portfolio_categories'
	);

	return apply_filters( 'mc_get_category_capabilities', $caps );
}

/**
 * Returns the capabilities for the portfolio tag taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return array
 */
function mc_get_tag_capabilities() {

	$caps = array(
		'manage_terms' => 'manage_portfolio_tags',
		'edit_terms'   => 'edit_portfolio_tags',
		'delete_terms' => 'delete_portfolio_tags',
		'assign_terms' => 'assign_portfolio_tags',
	);

	return apply_filters( 'mc_get_tag_capabilities', $caps );
}

/**
 * Returns the labels for the portfolio category taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return array
 */
function mc_get_category_labels() {

	$labels = array(
		'name'                       => __( 'Project Categories',                   'music-composition' ),
		'singular_name'              => __( 'Project Category',                     'music-composition' ),
		'menu_name'                  => __( 'Categories',                           'music-composition' ),
		'name_admin_bar'             => __( 'Category',                             'music-composition' ),
		'search_items'               => __( 'Search Categories',                    'music-composition' ),
		'popular_items'              => __( 'Popular Categories',                   'music-composition' ),
		'all_items'                  => __( 'All Categories',                       'music-composition' ),
		'edit_item'                  => __( 'Edit Category',                        'music-composition' ),
		'view_item'                  => __( 'View Category',                        'music-composition' ),
		'update_item'                => __( 'Update Category',                      'music-composition' ),
		'add_new_item'               => __( 'Add New Category',                     'music-composition' ),
		'new_item_name'              => __( 'New Category Name',                    'music-composition' ),
		'not_found'                  => __( 'No categories found.',                 'music-composition' ),
		'no_terms'                   => __( 'No categories',                        'music-composition' ),
		'items_list_navigation'      => __( 'Categories list navigation',           'music-composition' ),
		'items_list'                 => __( 'Categories list',                      'music-composition' ),

		// Hierarchical only.
		'select_name'                => __( 'Select Category',                      'music-composition' ),
		'parent_item'                => __( 'Parent Category',                      'music-composition' ),
		'parent_item_colon'          => __( 'Parent Category:',                     'music-composition' ),
	);

	return apply_filters( 'mc_get_category_labels', $labels );
}

/**
 * Returns the labels for the portfolio tag taxonomy.
 *
 * @since  1.0.0
 * @access public
 * @return array
 */
function mc_get_tag_labels() {

	$labels = array(
		'name'                       => __( 'Project Tags',                   'music-composition' ),
		'singular_name'              => __( 'Project Tag',                    'music-composition' ),
		'menu_name'                  => __( 'Tags',                           'music-composition' ),
		'name_admin_bar'             => __( 'Tag',                            'music-composition' ),
		'search_items'               => __( 'Search Tags',                    'music-composition' ),
		'popular_items'              => __( 'Popular Tags',                   'music-composition' ),
		'all_items'                  => __( 'All Tags',                       'music-composition' ),
		'edit_item'                  => __( 'Edit Tag',                       'music-composition' ),
		'view_item'                  => __( 'View Tag',                       'music-composition' ),
		'update_item'                => __( 'Update Tag',                     'music-composition' ),
		'add_new_item'               => __( 'Add New Tag',                    'music-composition' ),
		'new_item_name'              => __( 'New Tag Name',                   'music-composition' ),
		'not_found'                  => __( 'No tags found.',                 'music-composition' ),
		'no_terms'                   => __( 'No tags',                        'music-composition' ),
		'items_list_navigation'      => __( 'Tags list navigation',           'music-composition' ),
		'items_list'                 => __( 'Tags list',                      'music-composition' ),

		// Non-hierarchical only.
		'separate_items_with_commas' => __( 'Separate tags with commas',      'music-composition' ),
		'add_or_remove_items'        => __( 'Add or remove tags',             'music-composition' ),
		'choose_from_most_used'      => __( 'Choose from the most used tags', 'music-composition' ),
	);

	return apply_filters( 'mc_get_tag_labels', $labels );
}

/**
 * Register taxonomies for the plugin.
 *
 * @since  0.1.0
 * @access public
 * @return void.
 */
function mc_register_taxonomies() {

	// Set up the arguments for the portfolio category taxonomy.
	$cat_args = array(
		'public'            => true,
		'show_ui'           => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'query_var'         => mc_get_category_taxonomy(),
		'capabilities'      => mc_get_category_capabilities(),
		'labels'            => mc_get_category_labels(),

		// The rewrite handles the URL structure.
		'rewrite' => array(
			'slug'         => mc_get_category_rewrite_slug(),
			'with_front'   => false,
			'hierarchical' => false,
			'ep_mask'      => EP_NONE
		),
	);

	// Set up the arguments for the portfolio tag taxonomy.
	$tag_args = array(
		'public'            => true,
		'show_ui'           => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'show_admin_column' => true,
		'hierarchical'      => false,
		'query_var'         => mc_get_tag_taxonomy(),
		'capabilities'      => mc_get_tag_capabilities(),
		'labels'            => mc_get_tag_labels(),

		// The rewrite handles the URL structure.
		'rewrite' => array(
			'slug'         => mc_get_tag_rewrite_slug(),
			'with_front'   => false,
			'hierarchical' => false,
			'ep_mask'      => EP_NONE
		),
	);

	// Register the taxonomies.
	register_taxonomy( mc_get_category_taxonomy(), mc_get_project_post_type(), apply_filters( 'mc_category_taxonomy_args', $cat_args ) );
	register_taxonomy( mc_get_tag_taxonomy(),      mc_get_project_post_type(), apply_filters( 'mc_tag_taxonomy_args',      $tag_args ) );
}

/**
 * Filters the term updated messages in the admin.
 *
 * @since  1.0.0
 * @access public
 * @param  array  $messages
 * @return array
 */
function mc_term_updated_messages( $messages ) {

	$cat_taxonomy = mc_get_category_taxonomy();
	$tag_taxonomy = mc_get_tag_taxonomy();

	// Add the portfolio category messages.
	$messages[ $cat_taxonomy ] = array(
		0 => '',
		1 => __( 'Category added.',       'music-composition' ),
		2 => __( 'Category deleted.',     'music-composition' ),
		3 => __( 'Category updated.',     'music-composition' ),
		4 => __( 'Category not added.',   'music-composition' ),
		5 => __( 'Category not updated.', 'music-composition' ),
		6 => __( 'Categories deleted.',   'music-composition' ),
	);

	// Add the portfolio tag messages.
	$messages[ $tag_taxonomy ] = array(
		0 => '',
		1 => __( 'Tag added.',       'music-composition' ),
		2 => __( 'Tag deleted.',     'music-composition' ),
		3 => __( 'Tag updated.',     'music-composition' ),
		4 => __( 'Tag not added.',   'music-composition' ),
		5 => __( 'Tag not updated.', 'music-composition' ),
		6 => __( 'Tags deleted.',    'music-composition' ),
	);

	return $messages;
}
