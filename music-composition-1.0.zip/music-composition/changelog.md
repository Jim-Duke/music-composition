# Change Log

## [0.1.0]

* Plugin launch.  Based on version 2.1.0 of [custom-content-portfolio plugin](https://github.com/justintadlock/custom-content-portfolio) by [Justin Tadlock](https://themehybrid.com).
